package com.example.calculatorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView display;
    String spacedExpression = "";

    Button clearButton;
    Button signButton;
    Button percentButton;
    Button decimalButton;
    Button equalsButton;
    Button oneButton;
    Button twoButton;
    Button threeButton;
    Button fourButton;
    Button fiveButton;
    Button sixButton;
    Button sevenButton;
    Button eightButton;
    Button nineButton;
    Button zeroButton;
    Button divideButton;
    Button multiplyButton;
    Button subtractButton;
    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.id_textview_display);

        clearButton = findViewById(R.id.id_button_clear);
        signButton = findViewById(R.id.id_button_sign);
        percentButton = findViewById(R.id.id_button_percent);
        decimalButton = findViewById(R.id.id_button_decimal);
        equalsButton = findViewById(R.id.id_button_equals);
        oneButton = findViewById(R.id.id_button_one);
        twoButton = findViewById(R.id.id_button_two);
        threeButton = findViewById(R.id.id_button_three);
        fourButton = findViewById(R.id.id_button_four);
        fiveButton = findViewById(R.id.id_button_five);
        sixButton = findViewById(R.id.id_button_six);
        sevenButton = findViewById(R.id.id_button_seven);
        eightButton = findViewById(R.id.id_button_eight);
        nineButton = findViewById(R.id.id_button_nine);
        zeroButton = findViewById(R.id.id_button_zero);
        divideButton = findViewById(R.id.id_button_divide);
        multiplyButton = findViewById(R.id.id_button_multiply);
        subtractButton = findViewById(R.id.id_button_subtract);
        addButton = findViewById(R.id.id_button_add);

        clearButton.setOnClickListener(this);
        signButton.setOnClickListener(this);
        percentButton.setOnClickListener(this);
        decimalButton.setOnClickListener(this);
        equalsButton.setOnClickListener(this);
        oneButton.setOnClickListener(this);
        twoButton.setOnClickListener(this);
        threeButton.setOnClickListener(this);
        fourButton.setOnClickListener(this);
        fiveButton.setOnClickListener(this);
        sixButton.setOnClickListener(this);
        sevenButton.setOnClickListener(this);
        eightButton.setOnClickListener(this);
        nineButton.setOnClickListener(this);
        zeroButton.setOnClickListener(this);
        divideButton.setOnClickListener(this);
        multiplyButton.setOnClickListener(this);
        subtractButton.setOnClickListener(this);
        addButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (!(display.getText().equals("Error"))) {
            switch (view.getId()) {
                case R.id.id_button_clear:
                    display.setText("");
                    spacedExpression = "";
                    break;
                case R.id.id_button_sign:
                    display.setText(display.getText() + "-");
                    spacedExpression += "-";
                    break;
                case R.id.id_button_percent:
                    display.setText(display.getText() + "%");
                    spacedExpression += " % ";
                    break;
                case R.id.id_button_decimal:
                    display.setText(display.getText() + ".");
                    spacedExpression += ".";
                    break;
                case R.id.id_button_equals:
                    display.setText(evaluateExpression());
                    spacedExpression = display.getText() + "";
                    break;
                case R.id.id_button_one:
                    display.setText(display.getText() + "1");
                    spacedExpression += "1";
                    break;
                case R.id.id_button_two:
                    display.setText(display.getText() + "2");
                    spacedExpression += "2";
                    break;
                case R.id.id_button_three:
                    display.setText(display.getText() + "3");
                    spacedExpression += "3";
                    break;
                case R.id.id_button_four:
                    display.setText(display.getText() + "4");
                    spacedExpression += "4";
                    break;
                case R.id.id_button_five:
                    display.setText(display.getText() + "5");
                    spacedExpression += "5";
                    break;
                case R.id.id_button_six:
                    display.setText(display.getText() + "6");
                    spacedExpression += "6";
                    break;
                case R.id.id_button_seven:
                    display.setText(display.getText() + "7");
                    spacedExpression += "7";
                    break;
                case R.id.id_button_eight:
                    display.setText(display.getText() + "8");
                    spacedExpression += "8";
                    break;
                case R.id.id_button_nine:
                    display.setText(display.getText() + "9");
                    spacedExpression += "9";
                    break;
                case R.id.id_button_zero:
                    display.setText(display.getText() + "0");
                    spacedExpression += "0";
                    break;
                case R.id.id_button_divide:
                    display.setText(display.getText() + "÷");
                    spacedExpression += " ÷ ";
                    break;
                case R.id.id_button_multiply:
                    display.setText(display.getText() + "×");
                    spacedExpression += " × ";
                    break;
                case R.id.id_button_subtract:
                    display.setText(display.getText() + "−");
                    spacedExpression += " − ";
                    break;
                case R.id.id_button_add:
                    display.setText(display.getText() + "+");
                    spacedExpression += " + ";
                    break;
            }
        } else if (view.getId() == R.id.id_button_clear) {
            display.setText("");
            spacedExpression = "";
        }

        if (!(display.getText().equals(""))) {
            clearButton.setText("C");
        } else {
            clearButton.setText("AC");
        }
    }

    public CharSequence evaluateExpression() {
        String[] characters = spacedExpression.split(" ");

        ArrayList < String > charactersList = new ArrayList < > ();
        Collections.addAll(charactersList, characters);
        charactersList.removeAll(Collections.singleton(""));

        if (charactersList.size() == 0) { // blank expression evaluation
            return "";
        }

        try {
            for (int i = 0; i < charactersList.size() - 1;) { // multiplication/division/percent evaluation
                if (charactersList.get(i + 1).equals("×")) {
                    charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) * Double.parseDouble(charactersList.get(i + 2)) + "");
                    charactersList.remove(i);
                    charactersList.remove(i + 1);
                } else if (charactersList.get(i + 1).equals("÷")) {
                    charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) / Double.parseDouble(charactersList.get(i + 2)) + "");
                    charactersList.remove(i);
                    charactersList.remove(i + 1);
                } else if (charactersList.get(i + 1).equals("%")) {
                    if (i + 2 < charactersList.size() && !(charactersList.get(i + 2).equals("+") || charactersList.get(i + 2).equals("−") || charactersList.get(i + 2).equals("×") || charactersList.get(i + 2).equals("÷"))) {
                        charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) / 100 * Double.parseDouble(charactersList.get(i + 2)) + "");
                        charactersList.remove(i);
                        charactersList.remove(i + 1);
                    } else {
                        charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) / 100 + "");
                        charactersList.remove(i);
                    }
                } else {
                    i++;
                }
            }

            for (int i = 0; i < charactersList.size() - 1;) { // addition/subtraction evaluation
                if (charactersList.get(i + 1).equals("+")) {
                    charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) + Double.parseDouble(charactersList.get(i + 2)) + "");
                    charactersList.remove(i);
                    charactersList.remove(i + 1);
                } else if (charactersList.get(i + 1).equals("−")) {
                    charactersList.set(i + 1, Double.parseDouble(charactersList.get(i)) - Double.parseDouble(charactersList.get(i + 2)) + "");
                    charactersList.remove(i);
                    charactersList.remove(i + 1);
                } else {
                    i++;
                }
            }

            if (charactersList.get(0).equals("Infinity") || charactersList.get(0).equals("-Infinity")) { // divide by zero error, return statements
                return "Error";
            } else if (Double.parseDouble(charactersList.get(0)) % 1 == 0) {
                return (int)(Double.parseDouble(charactersList.get(0))) + "";
            } else {
                return Double.parseDouble(charactersList.get(0)) + "";
            }

        } catch (Exception e) { // general error
            return "Error";
        }
    }
}