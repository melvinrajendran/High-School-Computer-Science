package com.example.cookieclickerproject;

public class Upgrade {
    private boolean isPurchased;
    private int count;
    private int imageID;
    private int cost;

    public Upgrade(boolean isPurchased, int count, int imageID, int cost) {
        this.isPurchased = isPurchased;
        this.count = count;
        this.imageID = imageID;
        this.cost = cost;
    }

    public boolean isPurchased() {
        return isPurchased;
    }

    public void setPurchased(boolean purchased) {
        isPurchased = purchased;
    }

    public int getCount() {
        return count;
    }

    public void increaseCount() {
        count++;
        cost = (int)Math.round(cost * 1.1);
    }

    public int getImageID() {
        return imageID;
    }

    public int getCost() {
        return cost;
    }
}