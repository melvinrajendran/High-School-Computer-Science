package com.example.cookieclickerproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.res.ResourcesCompat;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity implements NameDialog.NameDialogListener {
    Button nameButton;
    TextView totalText;
    TextView rateText;
    TextView plusOneText;
    ImageView donutImageView;
    ImageView upgradeImageView;
    ConstraintLayout constraintLayout;

    //final ImageView backgroundImage1 = findViewById(R.id.id_imageview_background_1);
    //final ImageView backgroundImage2 = findViewById(R.id.id_imageview_background_2);

    int clickMultiplier = 1;

    static AtomicInteger donutTotal;

    float frostingOffset = 0.1f, sprinklesOffset = 0.075f, fryerOffset = 0.1f;

    PassiveIncomeThread passiveIncomeThread;

    Upgrade frostingUpgrade = new Upgrade(false, 0, R.drawable.frosting, 15);
    Upgrade sprinklesUpgrade = new Upgrade(false, 0, R.drawable.sprinkles, 100);
    Upgrade fryerUpgrade = new Upgrade(false, 0, R.drawable.fryer, 1000);

    AnimationSet donutAnimation = new AnimationSet(false);
    final ScaleAnimation enlargeAnimation = new ScaleAnimation(0.64f, 1.58f, 0.64f, 1.58f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
    final ScaleAnimation shrinkAnimation = new ScaleAnimation(1.58f, 0.64f, 1.58f, 0.64f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

    // add mini donut animation, moving screen animation
    // upgrade appears on screen
    // side menu for purchasing upgrades
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Donut Clicker!");

        /*final ValueAnimator animator = ValueAnimator.ofFloat(0.0f, 1.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(10000L);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                final float width = backgroundImage1.getWidth();
                final float translationX = width * progress;
                backgroundImage1.setTranslationX(translationX);
                backgroundImage2.setTranslationX(translationX - width);
            }
        });
        animator.start();*/

        nameButton = findViewById(R.id.id_button_name);
        totalText = findViewById(R.id.id_textview_total);
        rateText = findViewById(R.id.id_textview_rate);
        donutImageView = findViewById(R.id.id_imageview_donut);
        constraintLayout = findViewById(R.id.id_layout_constraint);

        donutTotal = new AtomicInteger(0);

        passiveIncomeThread = new PassiveIncomeThread();
        passiveIncomeThread.start();

        enlargeAnimation.setDuration(500);
        shrinkAnimation.setDuration(500);
        donutAnimation.addAnimation(enlargeAnimation);
        donutAnimation.addAnimation(shrinkAnimation);

        nameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NameDialog nameDialog = new NameDialog();
                nameDialog.show(getSupportFragmentManager(), "name dialog");
            }
        });

        donutImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Incrementing and displaying total number of donuts
                donutTotal.getAndAdd(clickMultiplier);
                totalText.setText(donutTotal.get() + " donuts");

                // Animating donut ImageView
                v.startAnimation(donutAnimation);

                ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);

                // Programmatically adding "+1" TextView to ConstraintLayout
                plusOneText = new TextView(constraintLayout.getContext());
                plusOneText.setId(View.generateViewId());
                plusOneText.setText("+" + clickMultiplier);
                plusOneText.setTextSize(20);
                Typeface typeface = ResourcesCompat.getFont(getApplicationContext(), R.font.luckiest_guy);
                plusOneText.setTypeface(typeface);
                plusOneText.setLayoutParams(layoutParams);

                constraintLayout.addView(plusOneText);

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.LEFT, constraintLayout.getId(), ConstraintSet.LEFT);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.RIGHT, constraintLayout.getId(), ConstraintSet.RIGHT);

                // Randomizing x-position of "+1" TextView
                float randomX = (float)(Math.random()) * 0.5f + 0.25f;
                constraintSet.setHorizontalBias(plusOneText.getId(), randomX);
                constraintSet.setVerticalBias(plusOneText.getId(), 0.4f);

                constraintSet.applyTo(constraintLayout);

                // Animating "+1" TextView
                plusOneText.animate().translationYBy(-800f).setDuration(3000).withStartAction(new Runnable() {
                    @Override
                    public void run() {
                        plusOneText.animate().alpha(0f).setDuration(3000);
                    }
                });
            }
        });
    }

    public class PassiveIncomeThread extends Thread {
        public void run() {
            while (true) {
                while (frostingUpgrade.isPurchased() || sprinklesUpgrade.isPurchased()) {
                    try {
                        Thread.sleep((long)1000/(frostingUpgrade.getCount() + 10 * sprinklesUpgrade.getCount()));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    donutTotal.getAndAdd(1);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            totalText.setText(donutTotal.get() + " donuts");
                            rateText.setText("per second: " + (frostingUpgrade.getCount() + 10 * sprinklesUpgrade.getCount()));
                        }
                    });
                }
            }
        }
    }

    @Override
    public void applyText(String name) {
        nameButton.setText(name + "'s Donut Shop");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.upgrade_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.upgrade1:
                if (donutTotal.get() >= frostingUpgrade.getCost()) {
                    frostingUpgrade.setPurchased(true);
                    donutTotal.set(donutTotal.get() - frostingUpgrade.getCost());
                    frostingUpgrade.increaseCount();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            totalText.setText(donutTotal.get() + " donuts");
                            rateText.setText("per second: " + (frostingUpgrade.getCount() + 10 * sprinklesUpgrade.getCount()));
                        }
                    });
                    item.setTitle("Frosting                         " + frostingUpgrade.getCost());

                    ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);

                    upgradeImageView = new ImageView(constraintLayout.getContext());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setImageResource(R.drawable.frosting);
                    upgradeImageView.setLayoutParams(layoutParams);

                    constraintLayout.addView(upgradeImageView);

                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.LEFT, constraintLayout.getId(), ConstraintSet.LEFT);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.RIGHT, constraintLayout.getId(), ConstraintSet.RIGHT);

                    constraintSet.setHorizontalBias(upgradeImageView.getId(), frostingOffset);
                    frostingOffset += 0.1f;
                    constraintSet.setVerticalBias(upgradeImageView.getId(), 0.73f);

                    constraintSet.applyTo(constraintLayout);

                    YoYo.with(Techniques.SlideInUp)
                            .duration(2000)
                            .playOn(upgradeImageView);
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(),"Insufficient Funds (Donuts)",Toast. LENGTH_SHORT);
                    toast.show();
                }

                return true;
            case R.id.upgrade2:
                if (donutTotal.get() >= sprinklesUpgrade.getCost()) {
                    sprinklesUpgrade.setPurchased(true);
                    donutTotal.set(donutTotal.get() - sprinklesUpgrade.getCost());
                    sprinklesUpgrade.increaseCount();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            totalText.setText(donutTotal.get() + " donuts");
                            rateText.setText("per second: " + (frostingUpgrade.getCount() + 10 * sprinklesUpgrade.getCount()));
                        }
                    });
                    item.setTitle("Sprinkles                     " + sprinklesUpgrade.getCost());

                    ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);

                    upgradeImageView = new ImageView(constraintLayout.getContext());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setImageResource(R.drawable.sprinkles);
                    upgradeImageView.setLayoutParams(layoutParams);

                    constraintLayout.addView(upgradeImageView);

                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.LEFT, constraintLayout.getId(), ConstraintSet.LEFT);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.RIGHT, constraintLayout.getId(), ConstraintSet.RIGHT);

                    constraintSet.setHorizontalBias(upgradeImageView.getId(), sprinklesOffset);
                    sprinklesOffset += 0.1f;
                    constraintSet.setVerticalBias(upgradeImageView.getId(), 0.83f);

                    constraintSet.applyTo(constraintLayout);

                    YoYo.with(Techniques.SlideInUp)
                            .duration(2000)
                            .playOn(upgradeImageView);
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(),"Insufficient Funds (Donuts)",Toast. LENGTH_SHORT);
                    toast.show();
                }

                return true;
            case R.id.upgrade3:
                if (donutTotal.get() >= fryerUpgrade.getCost()) {
                    fryerUpgrade.setPurchased(true);
                    donutTotal.set(donutTotal.get() - fryerUpgrade.getCost());
                    fryerUpgrade.increaseCount();
                    clickMultiplier = 1 + 5 * fryerUpgrade.getCount();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            totalText.setText(donutTotal.get() + " donuts");
                            rateText.setText("per second: " + (frostingUpgrade.getCount() + 10 * sprinklesUpgrade.getCount()));
                        }
                    });
                    item.setTitle("Fryer                           " + fryerUpgrade.getCost());

                    ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);

                    upgradeImageView = new ImageView(constraintLayout.getContext());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setId(View.generateViewId());
                    upgradeImageView.setImageResource(R.drawable.fryer);
                    upgradeImageView.setLayoutParams(layoutParams);

                    constraintLayout.addView(upgradeImageView);

                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(constraintLayout);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.LEFT, constraintLayout.getId(), ConstraintSet.LEFT);
                    constraintSet.connect(upgradeImageView.getId(), ConstraintSet.RIGHT, constraintLayout.getId(), ConstraintSet.RIGHT);

                    constraintSet.setHorizontalBias(upgradeImageView.getId(), fryerOffset);
                    fryerOffset += 0.1f;
                    constraintSet.setVerticalBias(upgradeImageView.getId(), 0.93f);

                    constraintSet.applyTo(constraintLayout);

                    YoYo.with(Techniques.SlideInUp)
                            .duration(2000)
                            .playOn(upgradeImageView);
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(),"Insufficient Funds (Donuts)",Toast. LENGTH_SHORT);
                    toast.show();
                }

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}