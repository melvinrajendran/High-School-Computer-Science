package com.example.cookieclickerproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity implements NameDialog.NameDialogListener {
    Button nameButton;
    TextView totalText, rateText, plusOneText;
    ImageView donutImageView;
    ConstraintLayout constraintLayout;

    static AtomicInteger donutTotal;

    AnimationSet donutAnimation = new AnimationSet(false);
    final ScaleAnimation enlargeAnimation = new ScaleAnimation(0.64f, 1.58f, 0.64f, 1.58f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
    final ScaleAnimation shrinkAnimation = new ScaleAnimation(1.58f, 0.64f, 1.58f, 0.64f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

    // add mini donut animation, moving screen animation
    // 2-3 upgrades, upgrade appears on screen
    // rate text
    // side menu for purchasing upgrades
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameButton = findViewById(R.id.id_button_name);
        totalText = findViewById(R.id.id_textview_total);
        rateText = findViewById(R.id.id_textview_rate);
        donutImageView = findViewById(R.id.id_imageview_donut);
        constraintLayout = findViewById(R.id.id_layout_constraint);

        donutTotal = new AtomicInteger(1);

        enlargeAnimation.setDuration(500);
        shrinkAnimation.setDuration(500);
        donutAnimation.addAnimation(enlargeAnimation);
        donutAnimation.addAnimation(shrinkAnimation);

        nameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NameDialog nameDialog = new NameDialog();
                nameDialog.show(getSupportFragmentManager(), "name dialog");
            }
        });

        donutImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Incrementing and displaying total number of donuts
                new MyThread().start();
                totalText.setText(donutTotal.get() + " donuts");

                // Animating donut ImageView
                v.startAnimation(donutAnimation);

                ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);

                // Programmatically adding "+1" TextView to ConstraintLayout
                plusOneText = new TextView(constraintLayout.getContext());
                plusOneText.setId(View.generateViewId());
                plusOneText.setText("+1");
                plusOneText.setTextSize(20);
                plusOneText.setLayoutParams(layoutParams);

                //put upgrade button here, imageviews, etc.

                constraintLayout.addView(plusOneText);

                //do this ^

                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(constraintLayout);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.TOP, constraintLayout.getId(), ConstraintSet.TOP);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.BOTTOM, constraintLayout.getId(), ConstraintSet.BOTTOM);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.LEFT, constraintLayout.getId(), ConstraintSet.LEFT);
                constraintSet.connect(plusOneText.getId(), ConstraintSet.RIGHT, constraintLayout.getId(), ConstraintSet.RIGHT);

                //do this ^

                // Randomizing x-position of "+1" TextView
                float randomX = (float)(Math.random()) * 0.5f + 0.25f;
                constraintSet.setHorizontalBias(plusOneText.getId(), randomX);
                constraintSet.setVerticalBias(plusOneText.getId(), 0.4f);

                constraintSet.applyTo(constraintLayout);

                // Animating "+1" TextView
                plusOneText.animate().translationYBy(-800f).setDuration(3000).withStartAction(new Runnable() {
                    @Override
                    public void run() {
                        plusOneText.animate().alpha(0f).setDuration(3000);
                    }
                });

                // animate here
            }
        });
    }

    public static class MyThread extends Thread {
        public void run() {
            try {
                Thread.sleep(2);
            } catch (Exception e) {
                System.out.println("Error");
            }

            donutTotal.getAndAdd(1);
        }
    }

    @Override
    public void applyText(String name) {
        nameButton.setText(name + "'s Donut Shop");
    }
}