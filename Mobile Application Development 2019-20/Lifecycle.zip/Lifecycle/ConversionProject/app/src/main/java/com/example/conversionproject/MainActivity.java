package com.example.conversionproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText feetText;
    TextView feetToMelvinsText;
    TextView melvinsToCookiesText;
    TextView cookiesToAirpods;
    TextView airpodsText;

    double feet;
    double melvins;
    double cookies;
    double airpods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        feetText = findViewById(R.id.id_edittext_feet);
        feetToMelvinsText = findViewById(R.id.id_textview_feet_to_melvins);
        melvinsToCookiesText = findViewById(R.id.id_textview_melvins_to_cookies);
        cookiesToAirpods = findViewById(R.id.id_textview_cookies_to_airpods);
        airpodsText = findViewById(R.id.id_textview_airpods);

        feetText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                feet = Integer.parseInt(s.toString());
            }
        });

        melvins = feet / 5.95;
        feetToMelvinsText.setText(" ");

        cookies = melvins * 20;
        airpods = cookies * 2;


    }
}
