package com.example.lifecycledemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String KEY_COUNTER = "Rise Up Lights";

    Button button;
    TextView textView;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("TAG", "CREATE");

        button = findViewById(R.id.id_button);
        textView = findViewById(R.id.id_text);

        // Extract information from bundle after connecting object IDs

        if (savedInstanceState != null) {
            counter = savedInstanceState.getInt(KEY_COUNTER, -99);
        }

        // Do not forget to re-assign values to necessary objects

        textView.setText("Counter: " + counter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter++;
                textView.setText("Counter: " + counter);
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_COUNTER, counter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("TAG", "START");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("TAG", "STOP");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TAG", "PAUSE");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("TAG", "DESTROY");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("TAG", "RESTART");
    }
}
