package com.example.gpsapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView latitudeText, longitudeText, distanceText, locationText;
    Button resetButton;

    LocationManager locationManager;
    LocationListener locationListener;
    ArrayList<Location> locationArrayList;
    ArrayList<Address> addressArrayList;
    Geocoder geocoder;

    String latitudeLabel = "   Latitude: ", longitudeLabel = "Longitude: ", distanceLabel = " meters";
    float totalDistance = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assigning reference IDs to displayed elements
        locationText = findViewById(R.id.id_textview_location);
        latitudeText = findViewById(R.id.id_textview_latitude);
        longitudeText = findViewById(R.id.id_textview_longitude);
        distanceText = findViewById(R.id.id_textview_distance);
        resetButton = findViewById(R.id.id_button_reset);

        // Creating on-click listener for Button resetButton
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                totalDistance = 0;
                distanceText.setText(totalDistance + distanceLabel);
            }
        });


        locationArrayList = new ArrayList<>();
        addressArrayList = new ArrayList<>();
        geocoder = new Geocoder(this, Locale.US);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Creating LocationListener locationListener to detect changes in location
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                // Displaying latitude and longitude
                latitudeText.setText(latitudeLabel + location.getLatitude());
                longitudeText.setText(longitudeLabel + location.getLongitude());

                // Displaying address
                try {
                    addressArrayList.add(geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1).get(0));
                    locationText.setText(addressArrayList.get(addressArrayList.size() - 1).getAddressLine(0));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                // Displaying total distance traveled
                locationArrayList.add(location);
                if (locationArrayList.size() >= 2) {
                    totalDistance += locationArrayList.get(locationArrayList.size() - 2).distanceTo(locationArrayList.get(locationArrayList.size() - 1));
                }
                distanceText.setText(totalDistance + distanceLabel);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

        // Checking and requesting Android permission ACCESS_FINE_LOCATION (if necessary)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListener);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putFloat("totalDistance", totalDistance);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        totalDistance = savedInstanceState.getFloat("totalDistance");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Fine Location Permission Granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Fine Location Permission Denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}
