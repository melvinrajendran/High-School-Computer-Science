package com.example.workoutapplication;

import java.util.ArrayList;

public class Session {
    String type;
    ArrayList<Exercise> exerciseArrayList;

    public Session(ArrayList<Exercise> exerciseArrayList) {
        this.exerciseArrayList = exerciseArrayList;

        ArrayList<String> stringArrayList = new ArrayList<>();
        for (int i = 0; i < exerciseArrayList.size(); i++) {
            if (!stringArrayList.contains(exerciseArrayList.get(i).getType())) {
                stringArrayList.add(exerciseArrayList.get(i).getType());
            }
        }
        switch (stringArrayList.size()) {
            case 0:
                type = "N/A";
                break;
            case 1:
                type = stringArrayList.get(0);
                break;
            case 2:
                type = stringArrayList.get(0) + " and " + stringArrayList.get(1);
                break;
            default:
                type = "Mixed";
                break;
        }
    }

    public String getType() {
        return type;
    }

    public void setType() {
        ArrayList<String> stringArrayList = new ArrayList<>();
        for (int i = 0; i < exerciseArrayList.size(); i++) {
            if (!stringArrayList.contains(exerciseArrayList.get(i).getType())) {
                stringArrayList.add(exerciseArrayList.get(i).getType());
            }
        }

        if (stringArrayList.size() == 0) {
            this.type = "N/A";
        } else if (stringArrayList.size() == 1) {
            this.type = stringArrayList.get(0);
        } else if (stringArrayList.size() == 2) {
            this.type = stringArrayList.get(0) + " and " + stringArrayList.get(1);
        } else {
            this.type = "Mixed";
        }
    }

    public ArrayList<Exercise> getExerciseArrayList() {
        return exerciseArrayList;
    }

    public void setExerciseArrayList(ArrayList<Exercise> exerciseArrayList) {
        this.exerciseArrayList = exerciseArrayList;
    }

    @Override
    public String toString() {
        String string = type + ":";

        if (exerciseArrayList.size() > 0) {
            for (Exercise exercise : exerciseArrayList) {
                string += "\n\t" + exercise;
            }
        }

        return string;
    }
}
