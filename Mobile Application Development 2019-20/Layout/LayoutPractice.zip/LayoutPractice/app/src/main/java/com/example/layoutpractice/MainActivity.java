package com.example.layoutpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button buttonOne;
    Button buttonTwo;
    Button buttonThree;
    Button buttonFour;
    Button buttonFive;

    TextView textOne;
    TextView textTwo;
    TextView textThree;
    TextView textFour;
    TextView textFive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonOne = findViewById(R.id.id_button_one);
        buttonTwo = findViewById(R.id.id_button_two);
        buttonThree = findViewById(R.id.id_button_three);
        buttonFour = findViewById(R.id.id_button_four);
        buttonFive = findViewById(R.id.id_button_five);

        textOne = findViewById(R.id.id_textview_one);
        textTwo = findViewById(R.id.id_textview_two);
        textThree = findViewById(R.id.id_textview_three);
        textFour = findViewById(R.id.id_textview_four);
        textFive = findViewById(R.id.id_textview_five);

        buttonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textOne.getText().equals("OFF"))
                    textOne.setText("ON");
                else
                    textOne.setText("OFF");
            }
        });

        buttonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textTwo.getText().equals("OFF"))
                    textTwo.setText("ON");
                else
                    textTwo.setText("OFF");
            }
        });

        buttonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textThree.getText().equals("OFF"))
                    textThree.setText("ON");
                else
                    textThree.setText("OFF");
            }
        });

        buttonFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textFour.getText().equals("OFF"))
                    textFour.setText("ON");
                else
                    textFour.setText("OFF");
            }
        });

        buttonFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textFive.getText().equals("OFF"))
                    textFive.setText("ON");
                else
                    textFive.setText("OFF");
            }
        });
    }
}
