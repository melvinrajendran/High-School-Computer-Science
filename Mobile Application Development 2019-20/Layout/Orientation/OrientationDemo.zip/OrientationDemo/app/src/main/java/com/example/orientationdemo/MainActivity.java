package com.example.orientationdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.id_text);
        button = findViewById(R.id.id_button);

        /*
         * button.setText("Landscape Button");
         * button does not exist in portrait mode
         */

        textView.setText(""+getResources().getConfiguration().orientation);

        // Method 1
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            button.setText("Landscape Button");
        }

        // Method 2
        if (button != null) {
            button.setText("Landscape Button 2");
        }
    }
}