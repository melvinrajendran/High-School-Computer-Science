package com.example.layoutpractice3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonOne;
    Button buttonTwo;
    Button buttonThree;

    boolean onePressed;
    boolean twoPressed;
    boolean threePressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonOne = findViewById(R.id.id_button_one);
        buttonTwo = findViewById(R.id.id_button_two);
        buttonThree = findViewById(R.id.id_button_three);

        buttonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onePressed = true;
                lockButtons();
            }
        });

        buttonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                twoPressed = true;
                lockButtons();
            }
        });

        buttonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                threePressed = true;
                lockButtons();
            }
        });
    }

    public void lockButtons() {
        if (onePressed && twoPressed && threePressed) {
            buttonOne.setClickable(false);
            buttonTwo.setClickable(false);
            buttonThree.setClickable(false);
        }
    }
}
