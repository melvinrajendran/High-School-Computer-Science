package com.example.chatbotapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    TextView stateText, stateNumberText;
    TextMessageReceiver textMessageReceiver;
    SmsMessage[] smsMessages;
    SmsManager smsManager = SmsManager.getDefault();
    Handler handler = new Handler();
    int state = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateText = findViewById(R.id.id_textview_state);
        stateNumberText = findViewById(R.id.id_textview_state_number);

        stateNumberText.setText("Current State: " + (state + 1));

        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, 1);
            return;
        }

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, 1);
        }

        textMessageReceiver = new TextMessageReceiver();
        registerReceiver(textMessageReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permissions Granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "SMS Permissions Denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    public Runnable createRunnable(final String message) {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                smsManager.sendTextMessage(smsMessages[0].getOriginatingAddress(), null, message, null, null);
            }
        };

        return runnable;
    }

    public class TextMessageReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            Object[] pdus = (Object[]) bundle.get("pdus");
            smsMessages = new SmsMessage[pdus.length];

            for (int i = 0; i < pdus.length; i++) {
                smsMessages[i] = SmsMessage.createFromPdu((byte[]) pdus[i], bundle.getString("format"));
            }

            Log.d("TAG", smsMessages[0].getOriginatingAddress() + ": " + smsMessages[0].getMessageBody());

            String inputMessage = smsMessages[0].getMessageBody();
            ArrayList<String> validResponses;
            ArrayList<String> randomResponses = new ArrayList<>(Arrays.asList("It was THREE LARGE SLICES! Unbelievable", "I checked today morning... You're a food thief", "It was $20. How could you?", "Are you kidding me?", "Leftover pizza is even better than regular :("));
            boolean validResponseFound;

            switch (state) {
                case 0:
                    validResponses = new ArrayList<>(Arrays.asList("Hi", "hi", "Hello", "hello", "Hey", "hey", "Howdy", "howdy", "What's up", "what's up", "Yo", "yo"));
                    validResponseFound = false;

                    for (int i = 0; i < validResponses.size(); i++) {
                        if (inputMessage.indexOf(validResponses.get(i)) != -1) {
                            stateText.setText("Greeting Detected. Introducing Argument.");
                            handler.postDelayed(createRunnable("We need to talk about something. ASAP"), 5000);
                            state++;
                            stateNumberText.setText("Current State: " + (state + 1));
                            validResponseFound = true;

                            break;
                        }
                    }

                    if (validResponseFound == false) {
                        stateText.setText("Greeting not Detected. Responding with Question.");
                        handler.postDelayed(createRunnable("You're not going to say hello?"), 5000);
                    }

                    break;
                case 1:
                    validResponses = new ArrayList<>(Arrays.asList("Okay", "okay", "What", "what", "What's up", "what's up", "Ok", "ok", "Fine", "fine", "Sure", "sure", "Yes", "yes"));
                    validResponseFound = false;

                    for (int i = 0; i < validResponses.size(); i++) {
                        if (inputMessage.indexOf(validResponses.get(i)) != -1) {
                            stateText.setText("Starting Argument.");
                            handler.postDelayed(createRunnable("I know you ate my leftover pizza that was in the fridge!"), 5000);
                            state++;
                            stateNumberText.setText("Current State: " + (state + 1));
                            validResponseFound = true;

                            break;
                        }
                    }

                    if (validResponseFound == false) {
                        stateText.setText("Unidentified input. Responding with Question.");
                        handler.postDelayed(createRunnable("Don't you wanna know what it is?"), 5000);
                    }

                    break;
                case 2:
                    validResponses = new ArrayList<>(Arrays.asList("When", "when"));
                    validResponseFound = false;

                    for (int i = 0; i < validResponses.size(); i++) {
                        if (inputMessage.indexOf(validResponses.get(i)) != -1) {
                            stateText.setText("Keyword \"When\" detected.  Continuing Argument.");
                            handler.postDelayed(createRunnable("Last night!  It was a large pie too."), 5000);
                            state++;
                            stateNumberText.setText("Current State: " + (state + 1));
                            validResponseFound = true;

                            break;
                        }
                    }

                    if (validResponseFound == false) {
                        stateText.setText("Keyword \"When\" not detected. Responding randomly.");
                        handler.postDelayed(createRunnable(randomResponses.get((int) (Math.random() * 5))), 5000);
                        state++;
                        stateNumberText.setText("Current State: " + (state + 1));
                    }

                    break;
                case 3:
                    stateText.setText("Asking for Justification.");
                    handler.postDelayed(createRunnable("Shut up. Why would you eat it? It wasn't yours"), 5000);
                    state++;
                    stateNumberText.setText("Current State: " + (state + 1));

                    break;
                case 4:
                    stateText.setText("Asking for Apology.");
                    handler.postDelayed(createRunnable("It doesn't matter. Are you gonna apologize?"), 5000);
                    state++;
                    stateNumberText.setText("Current State: " + (state + 1));

                    break;
                case 5:
                    validResponses = new ArrayList<>(Arrays.asList("Yes", "yes", "Yeah", "yeah", "Okay", "okay", "Ok", "ok", "Sorry", "sorry"));
                    validResponseFound = false;

                    for (int i = 0; i < validResponses.size(); i++) {
                        if (inputMessage.indexOf(validResponses.get(i)) != -1) {
                            stateText.setText("Ending Argument on Good Note.");
                            handler.postDelayed(createRunnable("Apology accepted. You're doing the dishes for the next year though. Bye"), 5000);
                            state++;
                            stateNumberText.setText("Current State: " + (state + 1));
                            validResponseFound = true;

                            break;
                        }
                    }

                    if (validResponseFound == false) {
                        stateText.setText("Ending Argument on Bad Note.");
                        handler.postDelayed(createRunnable("Ok. I get it. You're the worst roommate. Never talk to me again unless you buy me Pizza Hut. Large. Pepperoni. And Sprite."), 5000);
                        state++;
                        stateNumberText.setText("Current State: " + (state + 1));
                    }

                    break;
                default:
                    break;
            }
        }
    }
}