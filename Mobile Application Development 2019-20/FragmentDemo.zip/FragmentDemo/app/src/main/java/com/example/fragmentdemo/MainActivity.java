package com.example.fragmentdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements BottomFragment.SendInfo {

    Button replaceButton, clickButton;
    FragmentTransaction fragmentTransaction;
    FragmentManager fragmentManager;
    TextView topTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        replaceButton = findViewById(R.id.button);
        replaceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentManager = getSupportFragmentManager();

                fragmentTransaction = fragmentManager.beginTransaction();

                BottomFragment bottomFragment = new BottomFragment();
                fragmentTransaction.add(R.id.id_top,bottomFragment);

                fragmentTransaction.commit();
            }
        });

        topTextView = findViewById(R.id.top_text);

        clickButton = findViewById(R.id.id_button_click);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topTextView.setText("Clicked");
            }
        });

        fragmentManager = getSupportFragmentManager();

        //Begin first transaction
        fragmentTransaction = fragmentManager.beginTransaction();

        //Create bottom fragment and add to layout on bottom of XML
        BottomFragment bottomFragment = new BottomFragment();
        fragmentTransaction.add(R.id.id_bottom,bottomFragment);

        //commit the transaction (end)
        fragmentTransaction.commit();


    }

    @Override
    public void update(String str) {
        replaceButton.setText(str);
    }
}
