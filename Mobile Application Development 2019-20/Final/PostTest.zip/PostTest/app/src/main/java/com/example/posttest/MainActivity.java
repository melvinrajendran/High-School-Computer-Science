package com.example.posttest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    Button runButton;
    Button launchButton;
    ConstraintLayout constraintLayout;
    TextView nameText;

    Toast toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.id_radiogroup);
        runButton = findViewById(R.id.id_button_run);
        launchButton = findViewById(R.id.id_button_launch_app);
        constraintLayout = findViewById(R.id.id_layout);
        nameText = findViewById(R.id.id_textview_name);

        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (radioGroup.getCheckedRadioButtonId()) {
                    case R.id.id_radiobutton_1:
                        toast = Toast.makeText(MainActivity.this, "Toast Selected", Toast.LENGTH_SHORT);
                        toast.show();
                        break;
                    case R.id.id_radiobutton_2:
                        int random = (int)(Math.random() * 3);
                        switch (random) {
                            case 0:
                                constraintLayout.setBackgroundColor(Color.RED);
                                break;
                            case 1:
                                constraintLayout.setBackgroundColor(Color.BLUE);
                                break;
                            case 2:
                                constraintLayout.setBackgroundColor(Color.GREEN);
                                break;
                            default:
                                break;
                        }
                        break;
                    case R.id.id_radiobutton_3:
                        nameText.setAllCaps(true);
                        break;
                    default:
                        break;
                }
            }
        });

        launchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                switch (radioGroup.getCheckedRadioButtonId()) {
                    case R.id.id_radiobutton_1:
                        intent.putExtra("SELECTION", "The Toast Radio Button was selected");
                        break;
                    case R.id.id_radiobutton_2:
                        intent.putExtra("SELECTION", "The Change Color Radio Button was selected");
                        break;
                    case R.id.id_radiobutton_3:
                        intent.putExtra("SELECTION", "The Uppercase Radio Button was selected");
                        break;
                    default:
                        intent.putExtra("SELECTION", "No Radio Button was selected");
                        break;
                }

                startActivity(intent);
            }
        });
    }
}
