package com.example.finalreview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity {
    EditText editText; //at
    TextView textView;
    ImageView imageView;
    Spinner spinner; //
    RadioGroup radioGroup; //sr
    Toast toast; // Toast.makeText()
    Button button; // sv

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.id_edittext);
        textView = findViewById(R.id.id_textview);
        imageView = findViewById(R.id.id_imageview);
        spinner = findViewById(R.id.id_spinner);

        radioGroup = findViewById(R.id.id_radiogroup);
        toast = Toast.makeText(this, "This is an example Toast!", Toast.LENGTH_SHORT);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textView.setText(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        imageView.setImageResource(R.drawable.example);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.id_button_1:
                        Log.d("TAG", "Button 1");
                        break;
                    case R.id.id_button_2:
                        Log.d("TAG", "Button 2");
                        break;
                    case R.id.id_button_3:
                        Log.d("TAG", "Button 3");
                        break;
                }
            }
        });
    }
}
