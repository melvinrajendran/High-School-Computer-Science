package com.example.buttondemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonOne;
    Button buttonTwo;
    Button buttonThree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonOne = findViewById(R.id.id_button_one);
        buttonTwo = findViewById(R.id.id_button_two);
        buttonThree = findViewById(R.id.id_button_three);

        buttonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //buttonOne.setText("Hello");
                ((Button)v).setText("Hello");
            }
        });
    }

    /*public void onClickOne(View view) {
        int random = (int)(Math.random() * 2);

        if (random == 0)
            buttonOne.setTextColor(Color.RED);
        else
            buttonOne.setTextColor(Color.BLUE);
    }

    public void onClickTwo(View view) {
        buttonTwo.setTextColor(Color.GREEN);
    }

    public void onClickThree(View view) {
        CharSequence temp = buttonOne.getText();
        buttonOne.setText(buttonTwo.getText());
        buttonTwo.setText(temp);
    }*/

}