package com.example.buttonextrapractice;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonOne;
    Button buttonTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonOne = findViewById(R.id.id_button_one);
        buttonTwo = findViewById(R.id.id_button_two);

        buttonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int random = (int)(Math.random() * 7);

                switch (random) {
                    case 0:
                        ((Button)v).setTextColor(Color.RED);
                        break;
                    case 1:
                        ((Button)v).setTextColor(Color.BLUE);
                        break;
                    case 2:
                        ((Button)v).setTextColor(Color.GREEN);
                        break;
                    case 3:
                        ((Button)v).setTextColor(Color.BLACK);
                        break;
                    case 4:
                        ((Button)v).setTextColor(Color.WHITE);
                        break;
                    case 5:
                        ((Button)v).setTextColor(Color.YELLOW);
                        break;
                    case 6:
                        ((Button)v).setTextColor(Color.MAGENTA);
                        break;
                }
            }
        });

        buttonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CharSequence temp = buttonOne.getText();
                buttonOne.setText(buttonTwo.getText());
                buttonTwo.setText(temp);
            }
        });

        //buttonOne.setTooltipText("This is a button.");
        //requires Android API 26 or higher

    }
}
