package com.example.widgetquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText password;
    EditText reenterPassword;

    String passwordString = "";
    String reenterPasswordString = "";

    Button okButton;

    TextView usedPassword;

    Switch matchSwitch;

    ArrayList<String> passwordList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        passwordList.add("test");
        passwordList.add("123");
        passwordList.add("password");
        passwordList.add("abc");

        password = findViewById(R.id.id_edittext_password);
        reenterPassword = findViewById(R.id.id_edittext_reenter_password);

        okButton = findViewById(R.id.id_button_ok);

        usedPassword = findViewById(R.id.id_textview_used_password);

        matchSwitch = findViewById(R.id.id_switch_match);

        matchSwitch.setClickable(false);

        System.out.println(passwordList);

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                passwordString = s.toString();

                if (passwordList.contains(passwordString)) {
                    usedPassword.setText("Password Already Used");
                } else {
                    usedPassword.setText("Password Not Used");
                }
            }
        });

        reenterPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                reenterPasswordString = s.toString();
            }
        });

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (passwordString.equals(reenterPasswordString) && !(passwordList.contains(passwordString)) && !(passwordString.equals(""))) {
                    matchSwitch.setChecked(true);
                    passwordList.add(passwordString);
                    usedPassword.setText("Password Already Used");
                } else {
                    matchSwitch.setChecked(false);
                }

                System.out.println(passwordList);
            }
        });
    }
}