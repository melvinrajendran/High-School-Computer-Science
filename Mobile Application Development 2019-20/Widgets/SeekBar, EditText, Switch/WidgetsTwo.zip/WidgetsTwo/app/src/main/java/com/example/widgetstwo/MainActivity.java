package com.example.widgetstwo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Switch switchOne;
    Switch switchTwo;
    Switch switchThree;

    TextView colorText;
    TextView verifiedText;
    TextView databaseText;
    TextView textSizeText;

    EditText verifiedEditText;
    EditText databaseEditText;

    Button verifiedButton;
    Button databaseButton;

    SeekBar textSizeBar;

    boolean one = false;
    boolean two = false;
    boolean three = false;

    ArrayList < String > database = new ArrayList<>();

    int myProgress = 0;

    String eOne = "";
    String eTwo = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchOne = findViewById(R.id.id_switch_one);
        switchTwo = findViewById(R.id.id_switch_two);
        switchThree = findViewById(R.id.id_switch_three);

        colorText = findViewById(R.id.id_textview_color);
        verifiedText = findViewById(R.id.id_textview_verified);
        databaseText = findViewById(R.id.id_textview_database);
        textSizeText = findViewById(R.id.id_textview_textsize);

        verifiedEditText = findViewById(R.id.id_edittext_verified);
        databaseEditText = findViewById(R.id.id_edittext_database);

        verifiedButton = findViewById(R.id.id_button_verified);
        databaseButton = findViewById(R.id.id_button_database);

        textSizeBar = findViewById(R.id.id_seekbar_textsize);

        database.add("melvinr@gmail.com");
        database.add("therock@gmail.com");
        database.add("peterparker@gmail.com");

        switchOne.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                one = isChecked;

                if (one && two & three) {
                    colorText.setTextColor(Color.BLUE);
                } else if (one && three && !two) {
                    colorText.setTextColor(Color.RED);
                } else if (three && !one && !two) {
                    colorText.setTextColor(Color.GREEN);
                } else {
                    colorText.setTextColor(Color.GRAY);
                }
            }
        });

        switchTwo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                two = isChecked;

                if (one && two & three) {
                    colorText.setTextColor(Color.BLUE);
                } else if (one && three && !two) {
                    colorText.setTextColor(Color.RED);
                } else if (three && !one && !two) {
                    colorText.setTextColor(Color.GREEN);
                } else {
                    colorText.setTextColor(Color.GRAY);
                }
            }
        });

        switchThree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                three = isChecked;

                if (one && two & three) {
                    colorText.setTextColor(Color.BLUE);
                } else if (one && three && !two) {
                    colorText.setTextColor(Color.RED);
                } else if (three && !one && !two) {
                    colorText.setTextColor(Color.GREEN);
                } else {
                    colorText.setTextColor(Color.GRAY);
                }
            }
        });

        verifiedEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                eOne = s.toString();
            }
        });

        databaseEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                eTwo = s.toString();
            }
        });

        verifiedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (eOne.indexOf("@") != -1 && eOne.indexOf(".com") != -1 && eOne.indexOf("@") < eOne.indexOf(".com")) {
                    verifiedText.setText("Verified");
                } else {
                    verifiedText.setText("Not Verified");
                }
            }
        });

        databaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (database.contains(eTwo)) {
                    databaseText.setText("In Database");
                } else {
                    databaseText.setText("Not In Database");
                }
            }
        });

        textSizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                myProgress = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                textSizeText.setTextSize(myProgress);
            }
        });
    }
}
