package com.example.widgetsparttwodemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView selection;
    RadioGroup group;
    ImageView rightImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selection = findViewById(R.id.id_selection);
        group = findViewById(R.id.id_radiogroup);
        rightImage = findViewById(R.id.id_right_image);

        rightImage.setImageResource(R.drawable.darth);

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.id_radio_a) {
                    selection.setText("A");
                } else if (checkedId == R.id.id_radio_b) {
                    selection.setText("B");
                } else if (checkedId == R.id.id_radio_c) {
                    selection.setText("C");
                    Toast myToast = Toast.makeText(MainActivity.this, "C is the Best", Toast.LENGTH_SHORT);
                    myToast.show();
                }
            }
        });
    }
}
