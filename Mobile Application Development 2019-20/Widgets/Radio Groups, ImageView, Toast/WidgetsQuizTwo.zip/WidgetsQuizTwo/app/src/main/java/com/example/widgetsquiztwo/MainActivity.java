package com.example.widgetsquiztwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup group;
    Button playButton;
    ImageView computerImage;
    TextView totalText;
    TextView resultText;

    int playerInt = 0;
    int computerInt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        group = findViewById(R.id.id_radiogroup);
        playButton = findViewById(R.id.id_button_play);
        computerImage = findViewById(R.id.id_imageview_cpu);
        totalText = findViewById(R.id.id_textview_total);
        resultText = findViewById(R.id.id_textview_result);

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (playerInt != 0) {
                    computerImage.setImageResource(R.drawable.cpu);
                    totalText.setText("Total");
                    resultText.setText("Result");
                }

                if (checkedId == R.id.id_radiobutton_one) {
                    playerInt = 1;
                } else if (checkedId == R.id.id_radiobutton_two) {
                    playerInt = 2;
                }
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (playerInt != 0) {
                    computerInt = (int) (Math.random() * 2) + 1;

                    if (computerInt == 1) {
                        computerImage.setImageResource(R.drawable.number1);
                    } else {
                        computerImage.setImageResource(R.drawable.number2);
                    }

                    totalText.setText("Total is " + (playerInt + computerInt));

                    if ((playerInt + computerInt) % 2 == 0) {
                        resultText.setText("You Win!");
                    } else {
                        resultText.setText("CPU Wins.");
                    }
                } else {
                    Toast myToast = Toast.makeText(MainActivity.this, "Please Select a Number.", Toast.LENGTH_SHORT);
                    myToast.show();
                }
            }
        });
    }
}
