package com.example.widgetsparttwopracticetwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup volume;
    RadioGroup game;
    ImageView image;
    Button playButton;
    TextView selectionText;
    TextView scoreText;

    String playerObject = "";
    String computerObject = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        volume = findViewById(R.id.id_radiogroup_volume);
        game = findViewById(R.id.id_radiogroup_game);
        image = findViewById(R.id.id_image);
        playButton = findViewById(R.id.id_button_play);
        selectionText = findViewById(R.id.id_textview_selection);
        scoreText = findViewById(R.id.id_textview_score);

        image.setImageResource(R.drawable.logo);

        volume.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.id_radiobutton_100) {
                    Toast myToast = Toast.makeText(MainActivity.this, "100% volume may temporarily damage your hearing", Toast.LENGTH_SHORT);
                    myToast.show();
                }
            }
        });

        game.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.id_radiobutton_rock) {
                    playerObject = "Rock";
                } else if (checkedId == R.id.id_radiobutton_paper) {
                    playerObject = "Paper";
                } else if (checkedId == R.id.id_radiobutton_scissors) {
                    playerObject = "Scissors";
                }
            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (game.getCheckedRadioButtonId() != ) {

                }

                int random = (int)(Math.random()*3);
                if (random == 0) {
                    computerObject = "Rock";
                    image.setImageResource(R.drawable.rock);
                } else if (random == 1) {
                    computerObject = "Paper";
                    image.setImageResource(R.drawable.paper);
                } else {
                    computerObject = "Scissors";
                    image.setImageResource(R.drawable.scissors);
                }
            }
        });
    }
}
