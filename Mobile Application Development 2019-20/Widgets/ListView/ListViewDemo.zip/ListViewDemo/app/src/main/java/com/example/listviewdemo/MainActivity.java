package com.example.listviewdemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList <String> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

        arrayList = new ArrayList<>();
        arrayList.add("Bob");
        arrayList.add("Bill");
        arrayList.add("John");
        arrayList.add("Jim");
        arrayList.add("Jill");
        arrayList.add("Joe");
        arrayList.add("1");
        arrayList.add("60");
        arrayList.add("Jeff");
        arrayList.add("Rob");
        arrayList.add("Time");
        arrayList.add("Bobby");

        CustomAdapter customAdapter = new CustomAdapter(this, R.layout.adaper_custom, arrayList);
        listView.setAdapter(customAdapter);

    }

    public class CustomAdapter extends ArrayAdapter <String>
    {

        Context parentContext;
        List <String> list;
        int xmlResource;

        public CustomAdapter(@NonNull Context context, int resource, @NonNull List<String> objects) {
            super(context, resource, objects);
            parentContext = context;
            xmlResource = resource;
            list = objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)parentContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            View adapterView = layoutInflater.inflate(xmlResource, null);

            TextView name = adapterView.findViewById(R.id.adapterText);
            Button button  = adapterView.findViewById(R.id.adapterButton);

            name.setText("Name : " + list.get(position));
            button.setText("Posistion: " + position);

            return adapterView;

        }
    }
}
