package com.example.intentsdemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button launchButton;
    TextView resultText;

    static final int NUMBER_CODE = 1234;
    static final String INTENT_CODE = "SECRET CODE";

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == NUMBER_CODE && resultCode == RESULT_OK) {
            resultText.setText(data.getStringExtra(INTENT_CODE));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        launchButton = findViewById(R.id.id_button_launch);
        resultText = findViewById(R.id.id_textview_result);

        launchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // First parameter is context, second is class file
                Intent intentToLaunch = new Intent(MainActivity.this, NumberActivity.class);
                intentToLaunch.putExtra("TEST", "This is a test!");
                startActivityForResult(intentToLaunch, NUMBER_CODE);


                //startActivity(intentToLaunch);
            }
        });
    }
}
